package com.example.wechatmoment;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.bean.MessageContent;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.HashMap;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> implements ImageLoadingListener {

    private Context mContext;
    private List<MessageContent> mList;
    protected LayoutInflater inflater;
    private HashMap<String,ImageView> hashMap = new HashMap<String, ImageView>();

    public RecyclerViewAdapter(Context context) {
        mContext = context;
        inflater = LayoutInflater.from(context);
    }

    public void setList(List<MessageContent> messageContentList) {
        mList = messageContentList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View convertView = inflater.inflate(R.layout.item_content_grid, parent, false);
        ViewHolder viewHolder = new ViewHolder(convertView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.layout.setUrlList(mList.get(position).getImages());
        Log.d("liu","poaition =="+position);
        if(mList.get(position).getContent() == null || "".equalsIgnoreCase(mList.get(position).getContent())){
            holder.content.setVisibility(View.GONE);
        }else{
            holder.content.setText(mList.get(position).getContent());
        }
        if (mList.get(position).getSender().getUsername() != null){
            holder.username.setText(mList.get(position).getSender().getUsername());
        }
        Log.d("liu","username==="+mList.get(position).getSender().getUsername());
        hashMap.put(mList.get(position).getSender().getAvatar(),holder.avatar);
        ImageLoaderUtil.displayImage(mContext,mList.get(position).getSender().getAvatar(),ImageLoaderUtil.getPhotoImageOption(),this);
        if(mList.get(position).getComments()!=null && mList.get(position).getComments().size() > 0){
             holder.commentLayout.setCommentList(mList.get(position).getComments());
        }
    }

    @Override
    public int getItemCount() {
        return getListSize(mList);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        NineGridTestLayout layout;
        ImageView avatar;
        TextView username;
        TextView content;
        CommentLayout commentLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            layout = (NineGridTestLayout) itemView.findViewById(R.id.layout_nine_grid);
            avatar = (ImageView)itemView.findViewById(R.id.avatar);
            username = (TextView)itemView.findViewById(R.id.username);
            content = (TextView) itemView.findViewById(R.id.content);
            commentLayout = (CommentLayout)itemView.findViewById(R.id.comment);
        }
    }

    private int getListSize(List<MessageContent> list) {
        if (list == null || list.size() == 0) {
            return 0;
        }
        Log.d("liu","listSize==="+list.size());
        return list.size();
    }

    public void onLoadingStarted(String imageUri, View view) {

    }

    @Override
    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
        Log.d("liu","onLoadingFailed==="+failReason.getType());
    }

    @Override
    public void onLoadingComplete(String imageUri, View view, Bitmap bitmap) {
        if (hashMap.containsKey(imageUri)){
            ImageView imageView = (ImageView)hashMap.get(imageUri);
            imageView.setBackground(null);
            imageView.setImageBitmap(bitmap);
        }
    }

    @Override
    public void onLoadingCancelled(String imageUri, View view) {

    }
}
