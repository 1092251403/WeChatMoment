package com.example.wechatmoment;

import android.content.Context;
import android.content.pm.LauncherApps;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;
import com.nostra13.universalimageloader.core.imageaware.ImageViewAware;
import com.nostra13.universalimageloader.core.imageaware.NonViewAware;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.HashMap;
import java.util.List;

public class NineGridTestLayout extends NineGridLayout implements ImageLoadingListener{

    public NineGridTestLayout(Context context) {
        super(context);
    }

    public NineGridTestLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected boolean displayOneImage(final RatioImageView imageView, String url, final int parentWidth) {

        ImageLoaderUtil.displayImage(mContext, imageView, url, ImageLoaderUtil.getPhotoImageOption(), new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {

            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {

            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap bitmap) {

            }

            @Override
            public void onLoadingCancelled(String imageUri, View view) {

            }
        });
        return false;
    }


    public void onLoadingStarted(String imageUri, View view) {

    }

    @Override
    public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
        Log.d("liu","onLoadingFailed==="+failReason.getType());
        if (hashMap.containsKey(imageUri)){
            ImageView imageView = (ImageView)hashMap.get(imageUri);
            imageView.setBackground(mContext.getResources().getDrawable(R.drawable.banner_default));
        }
    }

    @Override
    public void onLoadingComplete(String imageUri, View view, Bitmap bitmap) {
            if (hashMap.containsKey(imageUri)){
               ImageView imageView = (ImageView)hashMap.get(imageUri);
                imageView.setImageBitmap(bitmap);
            }
    }

    @Override
    public void onLoadingCancelled(String imageUri, View view) {

    }

    HashMap<String, ImageView> hashMap = new HashMap<String, ImageView>();
    @Override
    protected void displayImage(RatioImageView imageView, String url) {
//       ImageLoaderUtil.getImageLoader(mContext).displayImage(url, imageView, ImageLoaderUtil.getPhotoImageOption());
        hashMap.put(url,imageView);
//        ImageLoaderUtil.getImageLoader(mContext).loadImage(url,ImageLoaderUtil.getPhotoImageOption(),this);

//        ImageSize targetImageSize = new ImageSize(30,30);
//        NonViewAware imageAware = new NonViewAware(url, targetImageSize, ViewScaleType.CROP);
//        ImageLoaderUtil.getImageLoader(mContext).displayImage(url,imageAware,ImageLoaderUtil.getPhotoImageOption(),this);

        ImageLoader.getInstance().displayImage(url,imageView,ImageLoaderUtil.getPhotoImageOption(),this);
    }

    @Override
    protected void onClickImage(int i, String url, List<String> urlList) {
        Toast.makeText(mContext, "点击了图片" + url, Toast.LENGTH_SHORT).show();
    }
}
