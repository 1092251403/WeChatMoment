package com.example.wechatmoment;

import android.content.pm.LauncherApps;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.design.widget.AppBarLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.util.ContentPresenter;
import com.example.bean.MessageContent;

import java.util.List;


public class MainActivity extends AppCompatActivity implements ContentPresenter.DataCallback{

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerViewAdapter mAdapter;
    private Handler handler=new Handler(){
        @Override
        public void handleMessage(Message msg)
        {
            super.handleMessage(msg);
            List<MessageContent> messageContentList = (List) msg.obj;
            if (msg.what==1){
                mAdapter.setList(messageContentList);
                mAdapter.notifyDataSetChanged();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ContentPresenter.setCallback(this);
        initView();
        getContentData();
    }

    private void initView(){
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new RecyclerViewAdapter(this);
        mRecyclerView.setAdapter(mAdapter);
    }

    private void getContentData(){
        ContentPresenter.getInstance().loadData("http://thoughtworks-ios.herokuapp.com/user/jsmith/tweets");
    }

    public void contentCallback(List<MessageContent> messageContentList){
        Message message = Message.obtain();
        message.what = 1;
        message.obj = messageContentList;
        handler.sendMessage(message);
    };
    public void userCallback(){

    };
}
